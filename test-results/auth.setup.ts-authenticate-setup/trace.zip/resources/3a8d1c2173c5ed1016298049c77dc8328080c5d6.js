(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/client/src/components/dashboard/RevenueChart.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_lodash_5f5730f7._.js",
  "static/chunks/node_modules_recharts_es6_109e2885._.js",
  "static/chunks/node_modules_d921fc44._.js",
  "static/chunks/client_src_components_dashboard_RevenueChart_tsx_7f1e787c._.js",
  "static/chunks/client_src_components_dashboard_RevenueChart_tsx_fa19ef2c._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/client/src/components/dashboard/RevenueChart.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/client/src/components/dashboard/ROIChart.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_lodash_6bd7a830._.js",
  "static/chunks/node_modules_recharts_es6_cbbe5bb4._.js",
  "static/chunks/node_modules_d921fc44._.js",
  "static/chunks/client_src_components_dashboard_ROIChart_tsx_e1062116._.js",
  "static/chunks/client_src_components_dashboard_ROIChart_tsx_fa19ef2c._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/client/src/components/dashboard/ROIChart.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
]);