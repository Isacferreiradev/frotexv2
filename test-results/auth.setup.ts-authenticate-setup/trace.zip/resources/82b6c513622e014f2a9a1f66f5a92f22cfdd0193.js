(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/client_src_components_dashboard_e15977e9._.js",
  "static/chunks/client_src_9d427eec._.js",
  "static/chunks/node_modules_4f1e241a._.js"
],
    source: "dynamic"
});
