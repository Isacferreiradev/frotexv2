(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__405e7fe1._.css",
  "static/chunks/node_modules_3dd6bbbd._.js",
  "static/chunks/client_src_476893b1._.js"
],
    source: "dynamic"
});
