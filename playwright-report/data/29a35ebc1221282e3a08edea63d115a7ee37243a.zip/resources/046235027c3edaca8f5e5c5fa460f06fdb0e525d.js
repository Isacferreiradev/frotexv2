(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/client_src_9635fee0._.js",
  "static/chunks/node_modules_next_99e9ab92._.js",
  "static/chunks/node_modules_zod_v4_1267b87d._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_56b6fd65._.js",
  "static/chunks/node_modules_motion-dom_dist_es_bc6a3e4a._.js",
  "static/chunks/node_modules_framer-motion_dist_es_afea34c2._.js",
  "static/chunks/node_modules_eea8790d._.js"
],
    source: "dynamic"
});
