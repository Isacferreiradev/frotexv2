(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/client_src_bc5399ab._.js",
  "static/chunks/node_modules_zod_v4_1267b87d._.js",
  "static/chunks/node_modules_06137809._.js"
],
    source: "dynamic"
});
